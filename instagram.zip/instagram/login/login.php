<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      background: #111; /* Dark background color */
    }

    form {
      position: relative;
      background: #333; /* Dark form background color */
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
      max-width: 400px;
      width: 100%;
      text-align: center;
      overflow: hidden;
    }

    h1 {
      color: #fff;
      font-size: 24px;
    }

    label {
      display: block;
      margin: 10px 0 5px;
      color: #fff;
    }

    input {
      width: calc(100% - 20px);
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #777;
      border-radius: 5px;
      background: #444; /* Input background color */
      color: #fff;
    }

    input[type="submit"] {
      background: #4CAF50; /* Submit button background color */
      color: #fff;
      cursor: pointer;
      transition: background 0.3s;
    }

    input[type="submit"]:hover {
      background: #45a049; /* Hover background color */
    }

    /* Background video styling */
    video {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: -1;
      opacity: 0.5; /* Adjust video opacity */
    }
  </style>
</head>
<body>
  <form action="proses_login.php" method="post">
    <img src="../images/pngegg.png" width="70px" alt="">
    <h1>LOGIN</h1>
    <label for="username">Username</label>
    <input type="text" name="username" id="username" required autocomplete="off"> 

    <label for="password">Password</label>
    <input type="password" name="password" id="password">

    <input type="submit" value="Login">
  </form>

  <!-- Background video -->
  <video autoplay muted loop>
    <source src="../video/onepiece.mp4" type="video/mp4">
    Your browser does not support the video tag.
  </video>
</body>
</html>
