<?php
include "koneksi.php";

session_start();

if(!isset($_SESSION['login'])){
    header("location:login/login.php?pesan=login");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Document</title>
</head>
<body>
    
    <div class="container">
        <br><br>
        <center>
            <h1>Upload Konten</h1>
        </center>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data" class="form-control">
        <label for="">Foto</label>
        <input type="file" name="gambar" id="" required class="form-control"><br><br>

        <label for="">Caption</label>
        <input type="text" name="caption" id="" autocomplete="off" class="form-control"><br>

        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" autocomplete="off" class="form-control"><br>

        <input type="submit" value="Simpan" name="simpan" class="btn btn-success">
    </form>
</div>
<script>
        function handleFormSubmit() {
            // You can add your form validation logic here before showing the SweetAlert
            // For demonstration, always show the SweetAlert
            Swal.fire({
                title: 'Simpan Berhasil!',
                text: 'Konten Anda berhasil disimpan.',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000 // Close after 2 seconds (adjust as needed)
            });

            // Prevent the default form submission
            return false;
        }
    </script>
</body>
</html>