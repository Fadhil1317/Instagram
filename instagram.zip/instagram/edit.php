<?php
include "koneksi.php";
session_start();

if(!isset($_SESSION['login'])){
    header("location:login/login.php?pesan=login");
}
$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Edit Siswa</h1>
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
        
        <label for="">Gambar</label>
        <input type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
        <input type="submit" value="Update" name="update">
    </form>
</body>
</html>

<?php } ?>