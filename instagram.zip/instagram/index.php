<?php
include "koneksi.php";
session_start();

if(!isset($_SESSION['login'])){
    header("location:login/login.php?pesan=login");
}
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- Include SweetAlert CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="icon" href="images/pngegg.png">
    <title>NimeGram</title>
    
</head>
<body style="background-color: #363434;">  
<script>
function confirmDelete(postId) {
    Swal.fire({
        title: 'Are you sure?',
        text: 'You won\'t be able to revert this!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Call your delete action here
            // <a href="hapus.php?no=<?=$post['no']?>"></a>
            window.location.href = 'hapus.php?no=' + postId ;
            // Example: window.location.href = 'delete.php?id=123';
            Swal.fire('Deleted!', 'Your data has been deleted.', 'success');
        }
    });
}

function confirmLogout() {
    Swal.fire({
        title: 'Are you sure?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, logout!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Call your delete action here
            window.location.href = 'login/logout.php' ;
            // Example: window.location.href = 'delete.php?id=123';
            Swal.fire('Deleted!', 'Your data has been deleted.', 'success');
        }
    });
}

document.addEventListener("DOMContentLoaded", function() {
        const form = document.getElementById("myForm");

        form.addEventListener("simpan", function(e) {
            e.preventDefault();

            Swal.fire({
                icon:"success",
                title: "Sukses!",
                text: "Cerita Anda telah berhasil ditambahkan",
                confirmButtonColor: "#3085d6",
                confirmButtonText: "Ok", 
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "simpan";
                }
            });
        });
    });
</script>

<nav class="navbar navbar-expand-lg sticky-top" style="background-color: #e5fa02;">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><img src="images/pngegg.png" width="50px" alt=""></a>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
    
        <a href="login/logout.php"></a>
        <button class="btn btn-primary" id="addEventListener" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-square-plus fa-l"> Upload</i></button><br><br>
        <button class="btn btn-outline-danger" onclick="confirmLogout()" ><i class="fa-solid fa-right-from-bracket fa-xl"></i></button>

    </div>
  </div>
</nav>
    <div class="container">
        <?php while($post = mysqli_fetch_assoc($query)){ ?>
            <center>
            
                <br>
            <div class="card" style="width: 18rem;">
            <div class="zoom">
            <img src="images/<?=$post['gambar']?>" class="card-img-top " alt="404" width="100" height="300">
            </div>
                <div class="card-body">
                    <p class="card-text"><?=$post['caption']?></p>
                    <p class="card-text">Lokasi : <?=$post['lokasi']?></p>
                    <a href="?no=<?=$post['no']?>"></a>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModalEdit<?=$post['no']?>"><i class="fa-regular fa-pen-to-square fa-fade fa-lg"></i></button>
                    <button class="btn btn-danger" onclick="confirmDelete(<?=$post['no']?>)" ><i class="fa-regular fa-trash-can fa-lg"></i></button>
                </div>
            </div> 
        </center>
         <!-- Modal Edit-->
    <div class="modal fade" id="exampleModalEdit<?=$post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Konten</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="proses_edit.php" method="post" enctype="multipart/form-data" class="form-control">
                    <input type="hidden" name="no" value="<?= $post['no'] ?>">
                    <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
                    
                    <label for="">Foto</label>
                    <input type="file" name="gambar" id="" required class="form-control" value="<?= $post['gambar'] ?>"><br>   

                    <label for="">Caption</label>
                    <input type="text" name="caption" id="" autocomplete="off" class="form-control" value="<?= $post['caption'] ?>"><br>

                    <label for="">Lokasi</label>
                    <input type="text" name="lokasi" id="" autocomplete="off" class="form-control" value="<?= $post['lokasi'] ?>"><br>
                    <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br><br>

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Edit" name="update" class="btn btn-success" onclick="contoh()">
                    </form>
                </div>
            </div>
        </div>
    </div>
        <?php } ?>
    </div>

    <!-- Modal Tambah-->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Upload Konten</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="myForm" action="proses_tambah.php" method="post" enctype="multipart/form-data" class="form-control">
                    <label for="">Foto</label>
                    <input type="file" name="gambar" id="" required class="form-control"><br>   

                    <label for="">Caption</label>
                    <input type="text" name="caption" id="" autocomplete="off" class="form-control"><br>

                    <label for="">Lokasi</label>
                    <input type="text" name="lokasi" id="" autocomplete="off" class="form-control"><br>

                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Simpan" name="simpan" class="btn btn-success" >
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>
</html>